# Currency-conversion- Extension

Add description ...


...


...


Add this dependency to your application pom.xml

```
<groupId>com.maypal.connector</groupId>
<artifactId>currency-convertor-connector-new</artifactId>
<version>1.0.0</version>
<classifier>mule-plugin</classifier>
```
