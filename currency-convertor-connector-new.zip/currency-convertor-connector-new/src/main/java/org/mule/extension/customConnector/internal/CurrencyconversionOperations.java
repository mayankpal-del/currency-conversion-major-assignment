package org.mule.extension.customConnector.internal;

import static org.mule.runtime.extension.api.annotation.param.MediaType.ANY;


import org.mule.runtime.extension.api.annotation.param.MediaType;
//import org.json.JSONException;
//import org.json.JSONObject;
import org.mule.runtime.extension.api.annotation.param.Config;
import org.mule.runtime.extension.api.annotation.param.Connection;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


/**
 * This class is a container for operations, every public method in this class will be taken as an extension operation.
 */
public class CurrencyconversionOperations {

  /**
   * Example of an operation that uses the configuration and a connection instance to perform some action.
   */
	private static final String API_URL = "https://api.exchangerate-api.com/v4/latest/";
	
	
  @MediaType(value = ANY, strict = false)
  public String retrieveInfo(@Config CurrencyconversionConfiguration configuration, @Connection CurrencyconversionConnection connection){
    return "Using Configuration [" + configuration.getConfigId() + "] with Connection id [" + connection.getId() + "]";
  }

  /**
   * Example of a simple operation that receives a string parameter and returns a new string message that will be set on the payload.
   */
  @MediaType(value = ANY, strict = false)
  public String sayHi(String person) {
    return buildHelloMessage(person);
  }

  /**
   * Private Methods are not exposed as operations
   */
  private String buildHelloMessage(String person) {
    return "Hello " + person + "!!!";
  }
  
  
  public double convertCurrency(String fromCurrency, String toCurrency, double amount) {
      try {
          // Make API request to fetch exchange rate
          String url = "https://api.exchangerate-api.com/v4/latest/" + fromCurrency;
          URL apiUrl = new URL(url);
          HttpURLConnection connection = (HttpURLConnection) apiUrl.openConnection();
          connection.setRequestMethod("GET");

          int responseCode = connection.getResponseCode();
          if (responseCode == HttpURLConnection.HTTP_OK) {
              BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
              String responseLine;
              StringBuilder response = new StringBuilder();

              while ((responseLine = reader.readLine()) != null) {
                  response.append(responseLine);
              }
              reader.close();

              // Parse JSON response to extract exchange rate
              String jsonResponse = response.toString();
              double exchangeRate = Double.parseDouble(jsonResponse.split("\"" + toCurrency + "\":")[1]
                      .split(",")[0]);

              // Perform currency conversion
              double convertedAmount = amount * exchangeRate;
              return convertedAmount;
          }
      } catch (Exception e) {
          e.printStackTrace();
      }

      return 0.0;
  }
  
}
  
  

  
  
  
  
